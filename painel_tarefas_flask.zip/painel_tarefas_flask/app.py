import os
import sqlite3
import requests

from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash


app = Flask(__name__)

# Em produção, configure uma variável de ambiente chamada SECRET_KEY.
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "chave-simples-para-estudo")

BANCO = "banco.db"


def conectar():
    conexao = sqlite3.connect(BANCO)
    conexao.row_factory = sqlite3.Row
    return conexao


def criar_tabelas():
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            senha TEXT NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            descricao TEXT,
            status TEXT NOT NULL,
            usuario_id INTEGER NOT NULL,
            FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        )
    """)

    conexao.commit()
    conexao.close()


def buscar_frase_motivacional():
    try:
        resposta = requests.get("https://api.adviceslip.com/advice", timeout=5)
        if resposta.status_code == 200:
            dados = resposta.json()
            return dados["slip"]["advice"]
    except Exception:
        pass

    return "Continue estudando. Cada pequeno avanço conta!"


def login_obrigatorio(funcao):
    @wraps(funcao)
    def wrapper(*args, **kwargs):
        if "usuario_id" not in session:
            flash("Faça login para acessar essa página.", "warning")
            return redirect(url_for("login"))
        return funcao(*args, **kwargs)
    return wrapper


@app.route("/")
def index():
    if "usuario_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/registro", methods=["GET", "POST"])
def registro():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "").strip()

        if not nome or not email or not senha:
            flash("Preencha todos os campos.", "danger")
            return redirect(url_for("registro"))

        senha_hash = generate_password_hash(senha)

        try:
            conexao = conectar()
            cursor = conexao.cursor()
            cursor.execute(
                "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
                (nome, email, senha_hash)
            )
            conexao.commit()
            conexao.close()

            flash("Conta criada com sucesso. Faça login.", "success")
            return redirect(url_for("login"))

        except sqlite3.IntegrityError:
            flash("Este e-mail já está cadastrado.", "danger")
            return redirect(url_for("registro"))

    return render_template("registro.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        senha = request.form.get("senha", "").strip()

        if not email or not senha:
            flash("Informe e-mail e senha.", "danger")
            return redirect(url_for("login"))

        conexao = conectar()
        cursor = conexao.cursor()
        cursor.execute("SELECT * FROM usuarios WHERE email = ?", (email,))
        usuario = cursor.fetchone()
        conexao.close()

        if usuario and check_password_hash(usuario["senha"], senha):
            session["usuario_id"] = usuario["id"]
            session["usuario_nome"] = usuario["nome"]

            flash("Login realizado com sucesso.", "success")
            return redirect(url_for("dashboard"))

        flash("E-mail ou senha inválidos.", "danger")
        return redirect(url_for("login"))

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Você saiu do sistema.", "info")
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_obrigatorio
def dashboard():
    usuario_id = session["usuario_id"]

    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute(
        "SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY id DESC",
        (usuario_id,)
    )
    tarefas = cursor.fetchall()
    conexao.close()

    frase = buscar_frase_motivacional()

    return render_template("dashboard.html", tarefas=tarefas, frase=frase)


@app.route("/nova-tarefa", methods=["GET", "POST"])
@login_obrigatorio
def nova_tarefa():
    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        descricao = request.form.get("descricao", "").strip()
        status = request.form.get("status", "").strip()

        status_validos = ["pendente", "em andamento", "concluida"]

        if not titulo or status not in status_validos:
            flash("Informe o título e escolha um status válido.", "danger")
            return redirect(url_for("nova_tarefa"))

        conexao = conectar()
        cursor = conexao.cursor()
        cursor.execute(
            """
            INSERT INTO tarefas (titulo, descricao, status, usuario_id)
            VALUES (?, ?, ?, ?)
            """,
            (titulo, descricao, status, session["usuario_id"])
        )
        conexao.commit()
        conexao.close()

        flash("Tarefa criada com sucesso.", "success")
        return redirect(url_for("dashboard"))

    return render_template("nova_tarefa.html")


@app.route("/editar/<int:id>", methods=["GET", "POST"])
@login_obrigatorio
def editar_tarefa(id):
    conexao = conectar()
    cursor = conexao.cursor()

    cursor.execute(
        "SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?",
        (id, session["usuario_id"])
    )
    tarefa = cursor.fetchone()

    if not tarefa:
        conexao.close()
        flash("Tarefa não encontrada.", "danger")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        titulo = request.form.get("titulo", "").strip()
        descricao = request.form.get("descricao", "").strip()
        status = request.form.get("status", "").strip()

        status_validos = ["pendente", "em andamento", "concluida"]

        if not titulo or status not in status_validos:
            flash("Informe o título e escolha um status válido.", "danger")
            return redirect(url_for("editar_tarefa", id=id))

        cursor.execute(
            """
            UPDATE tarefas
            SET titulo = ?, descricao = ?, status = ?
            WHERE id = ? AND usuario_id = ?
            """,
            (titulo, descricao, status, id, session["usuario_id"])
        )
        conexao.commit()
        conexao.close()

        flash("Tarefa atualizada com sucesso.", "success")
        return redirect(url_for("dashboard"))

    conexao.close()
    return render_template("editar_tarefa.html", tarefa=tarefa)


@app.route("/excluir/<int:id>", methods=["POST"])
@login_obrigatorio
def excluir_tarefa(id):
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute(
        "DELETE FROM tarefas WHERE id = ? AND usuario_id = ?",
        (id, session["usuario_id"])
    )
    conexao.commit()
    conexao.close()

    flash("Tarefa excluída com sucesso.", "info")
    return redirect(url_for("dashboard"))


@app.route("/concluir/<int:id>", methods=["POST"])
@login_obrigatorio
def concluir_tarefa(id):
    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute(
        """
        UPDATE tarefas
        SET status = ?
        WHERE id = ? AND usuario_id = ?
        """,
        ("concluida", id, session["usuario_id"])
    )
    conexao.commit()
    conexao.close()

    flash("Tarefa marcada como concluída.", "success")
    return redirect(url_for("dashboard"))


@app.route("/api/tarefas")
@login_obrigatorio
def api_tarefas():
    status = request.args.get("status", "").strip()
    usuario_id = session["usuario_id"]

    conexao = conectar()
    cursor = conexao.cursor()

    if status:
        cursor.execute(
            """
            SELECT * FROM tarefas
            WHERE usuario_id = ? AND status = ?
            ORDER BY id DESC
            """,
            (usuario_id, status)
        )
    else:
        cursor.execute(
            "SELECT * FROM tarefas WHERE usuario_id = ? ORDER BY id DESC",
            (usuario_id,)
        )

    tarefas = cursor.fetchall()
    conexao.close()

    lista = []
    for tarefa in tarefas:
        lista.append({
            "id": tarefa["id"],
            "titulo": tarefa["titulo"],
            "descricao": tarefa["descricao"],
            "status": tarefa["status"]
        })

    return jsonify(lista)


@app.route("/progresso")
@login_obrigatorio
def progresso():
    return render_template("progresso.html")


@app.route("/api/progresso")
@login_obrigatorio
def api_progresso():
    usuario_id = session["usuario_id"]

    conexao = conectar()
    cursor = conexao.cursor()
    cursor.execute(
        """
        SELECT status, COUNT(*) AS total
        FROM tarefas
        WHERE usuario_id = ?
        GROUP BY status
        """,
        (usuario_id,)
    )
    resultados = cursor.fetchall()
    conexao.close()

    dados = {
        "pendente": 0,
        "em andamento": 0,
        "concluida": 0
    }

    for item in resultados:
        dados[item["status"]] = item["total"]

    return jsonify(dados)


if __name__ == "__main__":
    criar_tabelas()

    # Para produção, mantenha debug=False.
    app.run(debug=False)
