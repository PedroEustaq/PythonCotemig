# Painel de Controle de Tarefas - Flask

Projeto simples para estudo de Flask com:

- Rotas e templates
- SQLite
- Login, registro e logout
- CRUD de tarefas
- Filtro por status com JSON
- Frase motivacional via API externa
- Bootstrap 5 e Bootstrap Icons
- Modo escuro com localStorage
- Gráfico com Chart.js

## Como rodar

1. Crie um ambiente virtual:

```bash
python -m venv venv
```

2. Ative o ambiente virtual:

Windows:

```bash
venv\Scripts\activate
```

Linux/Mac:

```bash
source venv/bin/activate
```

3. Instale as dependências:

```bash
pip install -r requirements.txt
```

4. Rode o projeto:

```bash
python app.py
```

5. Acesse no navegador:

```text
http://127.0.0.1:5000
```

## Observações

O banco SQLite será criado automaticamente no arquivo `banco.db`.

Para produção, altere a variável `SECRET_KEY` por uma chave segura de ambiente e mantenha `debug=False`.
