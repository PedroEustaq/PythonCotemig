function aplicarModoEscuroSalvo() {
    const modo = localStorage.getItem("modoEscuro");

    if (modo === "ativo") {
        document.body.classList.add("modo-escuro");
    }
}

function alternarModoEscuro() {
    document.body.classList.toggle("modo-escuro");

    if (document.body.classList.contains("modo-escuro")) {
        localStorage.setItem("modoEscuro", "ativo");
    } else {
        localStorage.setItem("modoEscuro", "inativo");
    }
}

function classeStatus(status) {
    if (status === "pendente") {
        return "status-pendente";
    }

    if (status === "em andamento") {
        return "status-em-andamento";
    }

    if (status === "concluida") {
        return "status-concluida";
    }

    return "";
}

function nomeStatus(status) {
    if (status === "concluida") {
        return "concluída";
    }

    return status;
}

function escaparTexto(texto) {
    const div = document.createElement("div");
    div.textContent = texto;
    return div.innerHTML;
}

function filtrarTarefas() {
    const select = document.getElementById("filtro-status");
    const lista = document.getElementById("lista-tarefas");

    if (!select || !lista) {
        return;
    }

    const status = encodeURIComponent(select.value);

    fetch(`/api/tarefas?status=${status}`)
        .then(function(resposta) {
            return resposta.json();
        })
        .then(function(tarefas) {
            lista.innerHTML = "";

            if (tarefas.length === 0) {
                lista.innerHTML = `
                    <div class="col-12">
                        <div class="alert alert-warning">
                            Nenhuma tarefa encontrada para esse filtro.
                        </div>
                    </div>
                `;
                return;
            }

            tarefas.forEach(function(tarefa) {
                const tituloSeguro = escaparTexto(tarefa.titulo);
                const descricaoSeguro = escaparTexto(tarefa.descricao || "Sem descrição.");
                const statusSeguro = escaparTexto(nomeStatus(tarefa.status));

                lista.innerHTML += `
                    <div class="col-md-4">
                        <div class="card h-100 shadow-sm tarefa-card ${classeStatus(tarefa.status)}">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <h5 class="card-title">${tituloSeguro}</h5>
                                    <span class="badge bg-secondary">${statusSeguro}</span>
                                </div>

                                <p class="card-text">${descricaoSeguro}</p>

                                <div class="d-flex gap-2 flex-wrap">
                                    <a href="/editar/${tarefa.id}" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                        Editar
                                    </a>

                                    <form method="post" action="/concluir/${tarefa.id}">
                                        <button class="btn btn-sm btn-outline-success">
                                            <i class="bi bi-check-circle"></i>
                                            Concluir
                                        </button>
                                    </form>

                                    <form method="post" action="/excluir/${tarefa.id}" onsubmit="return confirm('Deseja excluir esta tarefa?')">
                                        <button class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                            Excluir
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
        });
}

document.addEventListener("DOMContentLoaded", aplicarModoEscuroSalvo);
